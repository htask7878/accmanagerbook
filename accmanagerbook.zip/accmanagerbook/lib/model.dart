import 'package:flutter/material.dart';

class model {
  static TextEditingController t1 = TextEditingController();
  static TextEditingController datecontroller = TextEditingController();
  static TextEditingController amtcontroller = TextEditingController();
  static TextEditingController particontroller = TextEditingController();
  static TextEditingController search_controller = TextEditingController();
  static Color bluecolor = Color(0xff6334b4);
  static Color orangecolor = Color(0xffff5521);
  static Color whitecolor = Colors.white;
  static List? map;
  static String cid = "";
  static String type = "";
}
