package com.example.accmanagerbook;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
